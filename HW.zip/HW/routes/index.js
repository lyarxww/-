var express = require('express');
var router = express.Router();
var fs=require("fs")

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get("/myBOOK",function(req,res){
  res.render("BOOK.hbs",{
    fr1:"Может, однажды",
    fr2:"В метре друг от друга",
    fr3:"Весь этот мир",
    fr4:"180 секунд",
    fr5:"Орудие смерти"
    
  })
})

router.get("/user",function(req,res){
  console.log (req.query.userName)
  console.log (req.query.userAge)
  res.render("user.hbs", {
    name: req.query.userName,
    age: req.query.userAge
  })
})

router.get("/toTXT",function(req,res){
fs.appendFileSync("car.txt", req.query.autoName+" "+req.query.year+" "+req.query.price+"," )
res.render("car.hbs", {})
})

router.get("/listofCars", function(req,res){
  let carList=fs.readFileSync("car.txt", "utf8")
  res.render("carsList.hbs", {
    key1: carList
  })
})
module.exports = router;
